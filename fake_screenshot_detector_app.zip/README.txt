# Fake Screenshot Detector (Offline AI Version)

This Flutter app uses TensorFlow Lite to detect if a screenshot is REAL or FAKE entirely offline.

## How to use

1. Place your trained `model.tflite` file inside:
   ```
   assets/model.tflite
   ```

2. Open the folder in Android Studio or VS Code and run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```

3. Install the APK from:
   ```
   build/app/outputs/flutter-apk/app-release.apk
   ```

4. The app will run inference directly on your phone — no internet required!
