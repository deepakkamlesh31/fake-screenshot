import 'package:flutter/material.dart';
import 'home_page.dart';

void main() {
  runApp(const FakeScreenshotDetectorApp());
}

class FakeScreenshotDetectorApp extends StatelessWidget {
  const FakeScreenshotDetectorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fake Screenshot Detector',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const HomePage(),
    );
  }
}
