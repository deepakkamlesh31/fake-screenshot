import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {
  final String result;
  const ResultPage({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    bool isFake = result == 'FAKE';
    return Scaffold(
      appBar: AppBar(title: const Text('Detection Result')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(isFake ? Icons.close : Icons.check_circle,
                color: isFake ? Colors.red : Colors.green, size: 120),
            const SizedBox(height: 20),
            Text(
              isFake ? 'This Screenshot is FAKE' : 'This Screenshot is REAL',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Try Another'),
            ),
          ],
        ),
      ),
    );
  }
}
