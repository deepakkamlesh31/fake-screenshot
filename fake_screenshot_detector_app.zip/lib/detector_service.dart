import 'dart:io';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:tflite_flutter_helper/tflite_flutter_helper.dart';

class DetectorService {
  Future<String> detectFake(File image) async {
    try {
      final interpreter = await Interpreter.fromAsset('model.tflite');
      var input = List.generate(1, (i) => List.filled(224 * 224 * 3, 0.0));
      var output = List.filled(1, 2).reshape([1, 2]);

      interpreter.run(input, output);
      interpreter.close();

      double fakeScore = output[0][0];
      double realScore = output[0][1];

      return fakeScore > realScore ? 'FAKE' : 'REAL';
    } catch (e) {
      return 'Error: $e';
    }
  }
}
