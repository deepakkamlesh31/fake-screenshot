import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'detector_service.dart';
import 'result_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  File? _image;
  final picker = ImagePicker();
  bool _loading = false;

  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) setState(() => _image = File(pickedFile.path));
  }

  Future<void> _detectImage() async {
    if (_image == null) return;
    setState(() => _loading = true);
    final result = await DetectorService().detectFake(_image!);
    setState(() => _loading = false);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ResultPage(result: result)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fake Screenshot Detector')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_image != null)
              Image.file(_image!, height: 200)
            else
              const Icon(Icons.image, size: 150, color: Colors.grey),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.photo),
              label: const Text('Choose Screenshot'),
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: _detectImage,
              icon: const Icon(Icons.search),
              label: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Detect Fake / Real'),
            ),
          ],
        ),
      ),
    );
  }
}
